/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_9.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:59:02 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 07:59:25 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

int		init_ss(int *swapped, t_dirpair *dp)
{
	*swapped = 0;
	dp->subdir_next = dp->subdir;
	return (1);
}

void	order_all_by_path(t_env *env)
{
	t_path		*given_paths;
	t_dirpair	dp;
	int			swapped;
	t_auxpair	ap;

	given_paths = env->params;
	while (given_paths)
	{
		if (given_paths->subdirs && is_dir(given_paths->path))
		{
			if (given_paths->subdirs != 0)
				dp.subdir = given_paths->subdirs->next;
			swapped = 1;
			while (swapped == 1 && init_ss(&swapped, &dp) == 1)
				while (dp.subdir_next && dp.subdir_next->next)
				{
					make_auxes(&ap, dp);
					swap_if_needed(&dp, env, ap, &swapped);
					free_auxes_and_advance(&ap, &dp);
				}
		}
		given_paths = given_paths->next;
	}
}

void	swap_elems(t_element *a, t_element *b)
{
	char	*aux;

	aux = a->path;
	a->path = b->path;
	b->path = aux;
}

int		init_epts2(int *swapped, t_elempair *ep)
{
	ep->this_next = ep->this;
	*swapped = 0;
	return (1);
}

int		init_epts1(int *swapped, t_elempair *ep, t_dir *subdirs)
{
	*swapped = 1;
	ep->this = subdirs->files;
	return (1);
}
