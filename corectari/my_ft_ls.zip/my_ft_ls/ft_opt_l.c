/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_opt_l.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/23 09:24:29 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 07:40:38 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	make_dir(t_dir **dir)
{
	*dir = malloc(sizeof(t_dir*));
	init_max(*dir);
}

void	set_max_size(int *max_size, t_dir *dir)
{
	*max_size = dir->max_size;
	if (dir->m_maj + dir->m_min > *max_size && dir->m_maj + dir->m_min < 10)
		*max_size = dir->m_maj + dir->m_min + 2;
}

void	display_contents(char *name, t_dir *dir, int exception)
{
	struct stat		sb;
	int				max_size;
	char			*aux;

	aux = ft_strdup(name);
	if (exception == 1 && aux[ft_strlen(aux) - 1] == '/')
		aux[ft_strlen(aux) - 1] = '\0';
	lstat(aux, &sb);
	print_rights(sb, listxattr(aux, NULL, 0, XATTR_NOFOLLOW));
	if (!dir)
		make_dir(&dir);
	print_hardlinks(sb.st_nlink, dir->max_hardlinks);
	print_owner(sb.st_uid, dir->max_user_len);
	print_group(sb.st_gid, dir->max_group_len);
	set_max_size(&max_size, dir);
	if (S_ISBLK(sb.st_mode) || S_ISCHR(sb.st_mode))
		print_spec_size(sb.st_rdev, dir->m_maj, dir->m_min);
	else
		print_size(sb.st_size, max_size);
	print_time(sb.st_mtime);
	if (exception == 1)
		print_filename(sb, aux, 1);
	else
		print_filename(sb, aux, 0);
}
