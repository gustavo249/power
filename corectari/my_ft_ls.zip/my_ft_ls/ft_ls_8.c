/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_8.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:58:11 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 09:10:37 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

int		parent_of(char *a, char *b)
{
	char	*aux1;
	char	*aux2;

	aux1 = malloc(sizeof(char) * PATH_SIZE);
	aux2 = malloc(sizeof(char) * PATH_SIZE);
	ft_strcpy(aux1, a);
	ft_strcpy(aux2, b);
	aux1[ft_strlen(aux1) - 1] = '\0';
	aux2[ft_strlen(aux2) - 2] = '\0';
	if (ft_strlen(aux1) > ft_strlen(aux2) && ft_strrchr(aux1, '/'))
		aux1[ft_strrchr(aux1, '/') - aux1] = '\0';
	else if (ft_strlen(aux2) > ft_strlen(aux1) && ft_strrchr(aux2, '/'))
		aux2[ft_strrchr(aux2, '/') - aux2] = '\0';
	if (ft_strcmp(aux1, aux2) == 0)
	{
		free(aux1);
		free(aux2);
		return (1);
	}
	free(aux1);
	free(aux2);
	return (0);
}

int		siblings(char *a, char *b)
{
	char	*aux1;
	char	*aux2;

	aux1 = malloc(sizeof(char) * PATH_SIZE);
	aux2 = malloc(sizeof(char) * PATH_SIZE);
	ft_strcpy(aux1, a);
	ft_strcpy(aux2, b);
	if (ft_strrchr(aux1, '/') != ft_strchr(aux1, '/'))
		aux1[ft_strrchr(aux1, '/') - aux1] = '\0';
	if (ft_strrchr(aux1, '/'))
		aux1[ft_strrchr(aux1, '/') - aux1] = '\0';
	if (ft_strrchr(aux2, '/') != ft_strchr(aux2, '/'))
		aux2[ft_strrchr(aux2, '/') - aux2] = '\0';
	if (ft_strrchr(aux2, '/'))
		aux2[ft_strrchr(aux2, '/') - aux2] = '\0';
	if (ft_strcmp(aux1, aux2) == 0)
		return (1);
	return (0);
}

void	swap_if_needed(t_dirpair *dp, t_env *env, t_auxpair ap, int *swapped)
{
	if ((siblings(dp->subdir_next->path, dp->subdir_next->next->path) == 1 ||
	(parent_of(dp->subdir_next->path, dp->subdir_next->next->path) == 0 ||
	parent_of(dp->subdir_next->next->path, dp->subdir_next->path) == 0)) &&
	((ft_strcmp(ap.aux1, ap.aux2) < 0 && ft_strchr(env->flags, 'r') &&
	parent_of(dp->subdir_next->path, dp->subdir_next->next->path) == 0 &&
	parent_of(dp->subdir_next->next->path, dp->subdir_next->path) == 0) ||
	(ft_strcmp(ap.aux1, ap.aux2) > 0 && !ft_strchr(env->flags, 'r'))))
	{
		swap_dirs(dp->subdir_next, dp->subdir_next->next);
		*swapped = 1;
	}
}

void	make_auxes(t_auxpair *ap, t_dirpair dp)
{
	ap->aux1 = strdup(dp.subdir_next->path);
	ap->aux2 = strdup(dp.subdir_next->next->path);
	ap->aux1[ft_strlen(ap->aux1) - 1] = '\0';
	ap->aux2[ft_strlen(ap->aux2) - 1] = '\0';
}

void	free_auxes_and_advance(t_auxpair *ap, t_dirpair *dp)
{
	free(ap->aux1);
	free(ap->aux2);
	dp->subdir_next = dp->subdir_next->next;
}
