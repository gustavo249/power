/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_opt_t_all.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:47:35 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 07:48:08 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	t_init_stats(t_dirpair *dp, t_statpair *sp)
{
	sp->a_stat = malloc(sizeof(struct stat));
	sp->b_stat = malloc(sizeof(struct stat));
	lstat(dp->subdir_next->path, sp->a_stat);
	lstat(dp->subdir_next->next->path, sp->b_stat);
}

void	t_swap_and_advance(int *swapped, t_dirpair *dp, t_statpair *sp,
		t_env *env)
{
	if (
(siblings(dp->subdir_next->path, dp->subdir_next->next->path) == 1 ||
(parent_of(dp->subdir_next->path, dp->subdir_next->next->path) == 0 &&
parent_of(dp->subdir_next->next->path, dp->subdir_next->path) == 0)) &&
((sp->a_stat->st_mtime > sp->b_stat->st_mtime && ft_strchr(env->flags, 'r')) ||
(sp->a_stat->st_mtime < sp->b_stat->st_mtime && !ft_strchr(env->flags, 'r'))))
	{
		swap_dirs(dp->subdir_next, dp->subdir_next->next);
		*swapped = 1;
	}
	free(sp->a_stat);
	free(sp->b_stat);
	dp->subdir_next = dp->subdir_next->next;
}

void	order_all_by_path_time(t_env *env)
{
	t_path		*given_paths;
	int			swapped;
	t_dirpair	dp;
	t_statpair	sp;

	given_paths = env->params;
	while (given_paths)
	{
		if (is_dir(given_paths->path))
		{
			dp.subdir = given_paths->subdirs;
			swapped = 1;
			while (swapped == 1)
			{
				swapped = 0;
				dp.subdir_next = dp.subdir;
				while (dp.subdir_next && dp.subdir_next->next)
				{
					t_init_stats(&dp, &sp);
					t_swap_and_advance(&swapped, &dp, &sp, env);
				}
			}
		}
		given_paths = given_paths->next;
	}
}
