/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_opt_l_time_name.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:39:48 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 07:45:05 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	first_print(char *time)
{
	int i;

	i = 0;
	while (time[i] != '\0')
	{
		if (i >= 4 && i <= 15)
			write(1, time + i, 1);
		i++;
	}
	ft_putchar(' ');
}

void	second_print(char *time)
{
	int i;

	i = 0;
	while (time[i] != '\0')
	{
		if (i >= 4 && i <= 10)
			write(1, time + i, 1);
		if (i >= 19 && i <= 23)
			write(1, time + i, 1);
		i++;
	}
	ft_putchar(' ');
}

int		older_1970(char *time)
{
	if (ft_atoi(ft_strsub(time, 19, 5)) < 1970)
		return (1);
	else
		return (0);
}

void	print_time(time_t mtime)
{
	time_t	now;

	now = time((time_t*)NULL);
	if (older_1970(ctime(&(mtime))))
		ft_putstr("Jan  1  10000 ");
	else
	{
		if (mtime > now || mtime < (now - 15552000))
			second_print(ctime(&(mtime)));
		else
			first_print(ctime(&(mtime)));
	}
}

void	print_filename(struct stat sb, char *filename, int exception)
{
	ssize_t bytes_read;
	char	*link_read;
	char	*name;

	if (exception == 1)
		name = ft_strdup(filename);
	else
		name = ft_strdup(ft_strsub(filename,
		(ft_strrchr(filename, '/') - filename + 1), ft_strlen(filename)));
	if (S_ISLNK(sb.st_mode))
	{
		link_read = malloc(sizeof(char) * (PATH_SIZE + 1));
		ft_putstr(name);
		ft_putchar(' ');
		bytes_read = readlink(filename, link_read, PATH_SIZE);
		link_read[bytes_read] = '\0';
		ft_putstr("-> ");
		ft_putstr(link_read);
		ft_putchar('\n');
	}
	else
	{
		ft_putstr(name);
		ft_putchar('\n');
	}
}
