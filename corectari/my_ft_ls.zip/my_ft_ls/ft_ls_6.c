/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_6.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:57:13 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 09:08:29 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	erase_last_slash(char *aux)
{
	if (aux[ft_strlen(aux) - 1] == '/')
		aux[ft_strlen(aux) - 1] = '\0';
}

void	remove_first_2(char *aux)
{
	if (ft_strlen(aux) > 2 && ft_strncmp(aux, "./", 2) == 0)
		aux = ft_memcpy(aux, aux + 2, ft_strlen(aux));
}

void	print_bad_params(t_env *env)
{
	t_path		*path;
	struct stat	*stats;
	char		*aux;

	if (env == NULL || env->params == NULL)
		return ;
	path = env->params;
	while (path)
	{
		stats = malloc(sizeof(struct stat));
		if (path->path && lstat(path->path, stats) == -1)
		{
			if (errno == 2)
			{
				aux = ft_strdup(path->path);
				remove_first_2(aux);
				erase_last_slash(aux);
				no_such_file_error(aux);
			}
			*(path->path) = '\0';
		}
		path = path->next;
		free(stats);
	}
}

void	print_file(t_env *env, t_path *params, t_intpair *ip)
{
	if (!ft_strchr(env->flags, 'l'))
	{
		if (ft_strchr(params->path, '.') ==
				ft_strrchr(params->path, '.') &&
				ft_strchr(params->path, '.') != NULL)
			ft_putendl(ft_strsub(params->path, 2,
						ft_strlen(params->path)));
		else
			ft_putendl(params->path);
	}
	else
		display_contents(params->path, NULL, 0);
	ip->first = 0;
}

void	prepare_dir_print(t_intpair *ip, t_dir *dirs, t_path *params,
		t_env *env)
{
	if (ip->first_for_param == 1 && params->modified == 0)
		ip->first_for_param = 0;
	else
		dirs->path[ft_strlen(dirs->path) - 1] = '\0';
	if (ip->first == 1 && !env->params->next)
		ip->first = 0;
	else if (ip->first == 1 && (env->params->next ||
				env->params->subdirs->next))
	{
		ip->first = 0;
		ft_putstr(dirs->path);
		ft_putstr(":\n");
	}
	else
	{
		ft_putchar('\n');
		ft_putstr(dirs->path);
		ft_putstr(":\n");
	}
}
