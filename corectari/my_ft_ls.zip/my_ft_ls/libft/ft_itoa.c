/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/11/03 17:51:20 by alstanci          #+#    #+#             */
/*   Updated: 2015/11/04 10:04:14 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	do_cn(int n, long *cn, char **ret, int *i)
{
	*i = 0;
	if (n < 0)
	{
		*ret[*i] = '-';
		*i = *i + 1;
		*cn = n;
		*cn *= -1;
	}
	else
		*cn = n;
}

static void	count_zeroes(long *cn, char **ret, int *i, int *zeroes)
{
	*zeroes = 0;
	if (*cn == 0)
	{
		*ret[*i] = '0';
		*i = *i + 1;
	}
	while (*cn > 0 && *cn % 10 == 0)
	{
		*zeroes = *zeroes + 1;
		*cn = *cn / 10;
	}
}

char		*ft_itoa(int n)
{
	char	*ret;
	int		i;
	long	cn;
	long	rev;
	int		zeroes;

	rev = 0;
	ret = (char*)malloc(sizeof(char*) * 20);
	do_cn(n, &cn, &ret, &i);
	count_zeroes(&cn, &ret, &i, &zeroes);
	while (cn > 0)
	{
		rev = rev * 10 + cn % 10;
		cn /= 10;
	}
	while (rev > 0)
	{
		ret[i++] = (rev % 10) + '0';
		rev /= 10;
	}
	while (zeroes > 0 && zeroes--)
		ret[i++] = '0';
	ret[i] = 0;
	return (ret);
}
