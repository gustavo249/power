/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsplit.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/11/03 16:52:42 by alstanci          #+#    #+#             */
/*   Updated: 2015/11/09 10:22:25 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	get_word_count(char const *s, char c)
{
	int ret;
	int i;
	int other;

	other = 0;
	i = 0;
	ret = 0;
	while (s[i] != '\0')
	{
		if (s[i] != c)
			other = 1;
		if (s[i] == c && s[i + 1] != c && s[i + 1] != '\0')
			ret++;
		i++;
	}
	if (ret == 0 && other == 1)
		return (1);
	return (ret);
}

char		**ft_strsplit(char const *s, char c)
{
	int		word_count;
	int		i;
	int		j;
	int		k;
	char	**ret;

	j = 0;
	word_count = get_word_count(s, c);
	ret = (char**)malloc(sizeof(char**) * (word_count + 1));
	i = -1;
	while (++i < word_count)
		ret[i] = (char*)malloc(sizeof(char*) * ft_strlen(s));
	i = 0;
	while (i < word_count && s[j] != '\0')
	{
		while (s[j] == c && s[j] != '\0')
			j++;
		k = 0;
		while (s[j] != '\0' && s[j] != c && ++k && ++j)
			ret[i][k - 1] = s[j - 1];
		i++;
	}
	ret[word_count] = 0;
	return (ret);
}
