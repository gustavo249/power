/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/11/03 15:43:41 by alstanci          #+#    #+#             */
/*   Updated: 2015/11/04 10:03:51 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	char *ret;

	ret = (char *)malloc(sizeof(char*) * (ft_strlen(s1) + ft_strlen(s2)));
	ft_strcpy(ret, s1);
	ft_strcpy(ret + ft_strlen(s1), s2);
	return (ret);
}
