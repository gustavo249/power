/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdel.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/11/04 10:59:22 by alstanci          #+#    #+#             */
/*   Updated: 2015/11/04 11:05:11 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstdel(t_list **alst, void (*del)(void *, size_t))
{
	t_list *this;
	t_list *next;

	this = *alst;
	while (this)
	{
		next = this->next;
		del(this->content, this->content_size);
		free(this);
		this = next;
	}
	*alst = NULL;
}
