/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/10/22 09:46:31 by alstanci          #+#    #+#             */
/*   Updated: 2015/11/02 14:27:56 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dst, const void *src, size_t len)
{
	const unsigned char	*source;
	unsigned char		*dest;
	size_t				i;
	unsigned char		*aux;

	i = 0;
	source = src;
	dest = dst;
	aux = (unsigned char*)malloc(sizeof(unsigned char) * len);
	while (i < len)
	{
		aux[i] = source[i];
		i++;
	}
	i = 0;
	while (i < len)
	{
		dest[i] = aux[i];
		i++;
	}
	free(aux);
	return (dst);
}
