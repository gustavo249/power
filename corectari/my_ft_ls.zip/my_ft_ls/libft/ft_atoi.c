/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/10/27 14:10:16 by alstanci          #+#    #+#             */
/*   Updated: 2015/11/09 10:24:58 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_atoi(const char *chr)
{
	long	ret;
	char	*string;
	int		isnegative;

	isnegative = 1;
	string = (char*)chr;
	ret = 0;
	while (*string == ' ' || *string == '\n' || *string == '\t' ||
			*string == '\v' || *string == '\r' || *string == '\f')
		string++;
	if (*string == '+')
	{
		if (*(string + 1) != '\0' && (*(string + 1) < '0' ||
					*(string + 1) > '9'))
			return (0);
		string++;
	}
	if (*string == '-' && ++string)
		isnegative *= -1;
	while (ft_isdigit(*string))
	{
		ret = ret * 10 + *string - '0';
		string++;
	}
	return (ret * isnegative);
}
