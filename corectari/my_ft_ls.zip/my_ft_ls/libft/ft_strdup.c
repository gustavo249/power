/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/10/22 11:04:49 by alstanci          #+#    #+#             */
/*   Updated: 2015/11/02 14:24:16 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s1)
{
	int		i;
	int		b;
	char	*z;

	b = ft_strlen(s1) + 1;
	z = (char*)malloc(sizeof(char) * b);
	i = 0;
	while (i < b)
	{
		z[i] = s1[i];
		i++;
	}
	z[i] = '\0';
	return (z);
}
