/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/10/22 11:19:41 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/07 11:49:02 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strcat(char *s1, const char *s2)
{
	char		*first;
	const char	*second;

	first = s1;
	second = s2;
	while (*first != '\0')
		first++;
	while (*second != '\0')
	{
		*first = *second;
		first++;
		second++;
	}
	*first = '\0';
	return (s1);
}
