/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/11/03 15:51:32 by alstanci          #+#    #+#             */
/*   Updated: 2015/11/03 16:51:41 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strtrim(char const *s)
{
	int		n;
	int		i;
	int		j;
	char	*ret;

	n = 0;
	i = 0;
	ret = (char*)malloc(sizeof(char*) * ft_strlen(s));
	while ((s[i] == ' ' || s[i] == '\t' || s[i] == '\n') && s[i] != '\0')
		i++;
	n = i;
	while (s[i] != '\0')
		i++;
	while (--i && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n') && i > 0)
		;
	j = i;
	i = 0;
	if (n == 0 && s[j] == '\0')
		ft_strcpy(ret, s);
	else
		while (n <= j && ++n && ++i)
			ret[i - 1] = s[n - 1];
	return (ret);
}
