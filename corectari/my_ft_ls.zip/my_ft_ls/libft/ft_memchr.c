/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/10/22 09:49:23 by alstanci          #+#    #+#             */
/*   Updated: 2015/10/27 16:27:47 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memchr(const void *s, int c, size_t n)
{
	unsigned char		target;
	const unsigned char	*source;
	size_t				i;

	i = 0;
	source = s;
	target = c;
	while (i < n)
	{
		if (source[i] == target)
			return ((void*)(source + i));
		i++;
	}
	return (NULL);
}
