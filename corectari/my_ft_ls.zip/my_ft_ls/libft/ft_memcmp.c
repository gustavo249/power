/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/10/22 09:55:24 by alstanci          #+#    #+#             */
/*   Updated: 2015/10/27 16:28:18 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_memcmp(const void *s1, const void *s2, size_t n)
{
	size_t				i;
	unsigned const char	*one;
	unsigned const char	*two;

	i = 0;
	one = s1;
	two = s2;
	while (i < n)
	{
		if (*one != *two)
			return (*one - *two);
		one++;
		two++;
		i++;
	}
	return (0);
}
