/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_5.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:56:48 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 09:08:00 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	make_sub_paths(t_path *path, char *flags)
{
	t_path	*this;
	t_dir	*current_dir;

	this = path;
	if (this->subdirs == NULL)
	{
		this->subdirs = (t_dir*)malloc(sizeof(t_dir));
		this->subdirs->path = (char*)malloc(sizeof(char) * PATH_SIZE);
		this->subdirs->files = NULL;
		this->subdirs->next = NULL;
		init_max(this->subdirs);
		ft_strcpy(this->subdirs->path, this->path);
	}
	current_dir = this->subdirs;
	while (current_dir)
	{
		read_dir(&current_dir, flags);
		current_dir = current_dir->next;
	}
}

void	make_paths(t_env *env)
{
	t_path	*params;
	int		l_flag;
	int		is_lnk;

	l_flag = 0;
	if (ft_strchr(env->flags, 'l'))
		l_flag = 1;
	if (env->params == NULL)
	{
		env->params = (t_path*)malloc(sizeof(t_path));
		env->params->path = (char*)malloc(sizeof(char) * PATH_SIZE);
		env->params->subdirs = NULL;
		env->params->next = NULL;
		ft_strcpy(env->params->path, "./");
	}
	params = env->params;
	while (params)
	{
		is_lnk = is_link(params->path, params->modified);
		if ((is_lnk == 0 && is_dir(params->path)) ||
				(is_lnk == 1 && l_flag == 0 && is_dir(params->path)))
			make_sub_paths(params, env->flags);
		is_lnk = 0;
		params = params->next;
	}
}

int		compare_dates(struct tm *d1, struct tm *d2)
{
	if (d1->tm_year < d2->tm_year)
		return (-1);
	else if (d1->tm_year > d2->tm_year)
		return (1);
	else
	{
		if (d1->tm_mon < d2->tm_mon)
			return (-1);
		else if (d1->tm_mon > d2->tm_mon)
			return (1);
		else if (d1->tm_mday < d2->tm_mday)
			return (-1);
		else if (d1->tm_mday > d2->tm_mday)
			return (1);
		else
			return (0);
	}
}

void	print_blocks(t_dir *directory)
{
	long		size;
	t_element	*this;
	struct stat *stats;

	this = directory->files;
	size = 0;
	while (this)
	{
		stats = (struct stat*)malloc(sizeof(struct stat));
		lstat(this->path, stats);
		size += stats->st_blocks;
		this = this->next;
		free(stats);
	}
	ft_putstr("total ");
	ft_putnbr(size);
	ft_putchar('\n');
}

void	no_such_file_error(char *aux)
{
	write_stderror("ls: ");
	write_stderror(aux);
	write_stderror(": No such file or directory\n");
}
