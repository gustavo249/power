/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_opt_t_contents.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:46:41 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 07:53:32 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

int		init_ep_swapped(int *swapped, t_elempair *ep, t_dir *subdirs,
		int init_case)
{
	if (init_case == 1)
	{
		ep->this = subdirs->files;
		*swapped = 1;
		return (1);
	}
	else
	{
		ep->this_next = ep->this;
		*swapped = 0;
		return (1);
	}
}

void	init_stats(t_statpair *sp, t_elempair *ep)
{
	sp->a_stat = malloc(sizeof(struct stat));
	sp->b_stat = malloc(sizeof(struct stat));
	lstat(ep->this_next->path, sp->a_stat);
	lstat(ep->this_next->next->path, sp->b_stat);
}

void	t_free_and_advance(t_elempair *ep, t_statpair *sp)
{
	free(sp->a_stat);
	free(sp->b_stat);
	ep->this_next = ep->this_next->next;
}

void	t_swap_elems_if_needed(int *swapped, t_elempair *ep, t_statpair *sp,
		t_env *env)
{
	if (
(sp->a_stat->st_mtime > sp->b_stat->st_mtime && ft_strchr(env->flags, 'r')) ||
(sp->a_stat->st_mtime < sp->b_stat->st_mtime && !ft_strchr(env->flags, 'r')))
	{
		*swapped = 1;
		swap_elems(ep->this_next, ep->this_next->next);
	}
	else if (sp->a_stat->st_mtime == sp->b_stat->st_mtime)
	{
		if (
			(ft_strcmp(ep->this_next->path, ep->this_next->next->path) < 0 &&
			ft_strchr(env->flags, 'r')) ||
			(ft_strcmp(ep->this_next->path, ep->this_next->next->path) > 0 &&
			!ft_strchr(env->flags, 'r')))
		{
			*swapped = 1;
			swap_elems(ep->this_next, ep->this_next->next);
		}
	}
	t_free_and_advance(ep, sp);
}

void	order_contents_time(t_env *env)
{
	t_path		*params;
	t_dir		*subdirs;
	int			swapped;
	t_elempair	ep;
	t_statpair	sp;

	params = env->params;
	while (params)
	{
		if (is_dir(params->path))
		{
			subdirs = params->subdirs;
			while (subdirs && init_ep_swapped(&swapped, &ep, subdirs, 1))
			{
				while (swapped && init_ep_swapped(&swapped, &ep, subdirs, 0))
					while (ep.this_next && ep.this_next->next)
					{
						init_stats(&sp, &ep);
						t_swap_elems_if_needed(&swapped, &ep, &sp, env);
					}
				subdirs = subdirs->next;
			}
		}
		params = params->next;
	}
}
