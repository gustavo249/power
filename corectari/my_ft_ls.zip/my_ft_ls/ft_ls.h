/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/11/24 15:34:29 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 09:03:49 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_LS_H
# define FT_LS_H
# define PATH_SIZE 4096
# include "libft/includes/libft.h"
# include <unistd.h>
# include <stdlib.h>
# include <fcntl.h>
# include <sys/stat.h>
# include <dirent.h>
# include <sys/types.h>
# include <pwd.h>
# include <uuid/uuid.h>
# include <grp.h>
# include <sys/xattr.h>
# include <time.h>
# include <stdio.h>
# include <errno.h>

typedef	struct			s_file_stats
{
	char				*date;
	char				*owner_name;
	char				*group_name;
	nlink_t				nb_link;
	char				*file_name;
	off_t				file_size;
	char				*file_mode;
}						t_file_stats;

typedef struct			s_element
{
	char				*path;
	struct s_element	*next;
}						t_element;

typedef struct			s_dir
{
	int					max_user_len;
	int					max_group_len;
	int					max_hardlinks;
	int					max_size;
	int					m_maj;
	int					m_min;
	char				*path;
	int					error;
	t_element			*files;
	struct s_dir		*next;
}						t_dir;

typedef struct			s_path
{
	char				*path;
	t_dir				*subdirs;
	struct s_path		*next;
	int					modified;
}						t_path;

typedef struct			s_env
{
	char				*flags;
	t_path				*params;
}						t_env;

typedef struct			s_spg
{
	struct stat			*stats;
	struct passwd		*pwd;
	struct group		*grp;
}						t_spg;

typedef struct			s_ep
{
	t_element			*contents;
	t_element			*next;
}						t_ep;

typedef struct			s_dfp
{
	t_dir				**current_dir;
	char				*flags;
}						t_dfp;

typedef struct			s_intpair
{
	int					first;
	int					first_for_param;
}						t_intpair;

typedef struct			s_auxpair
{
	char				*aux1;
	char				*aux2;
}						t_auxpair;

typedef struct			s_dirpair
{
	t_dir				*subdir;
	t_dir				*subdir_next;
}						t_dirpair;

typedef struct			s_elempair
{
	t_element			*this;
	t_element			*this_next;
}						t_elempair;

typedef struct			s_lenpair
{
	int len1;
	int len2;
}						t_lenpair;

typedef struct			s_statpair
{
	struct stat			*a_stat;
	struct stat			*b_stat;
}						t_statpair;

typedef struct			s_pathpair
{
	t_path				*this;
	t_path				*this_next;
}						t_pathpair;

void					display_contents(char *name, t_dir *dir, int exception);
void					init_max(t_dir *dir);
int						is_dir(char *path);
int						is_file(char *path);
void					order_params_by_time(t_env *env);
void					order_contents_time(t_env *env);
void					order_all_by_path_time(t_env *env);
int						siblings(char *a, char *b);
void					swap_dirs(t_dir *a, t_dir *b);
void					swap_elems(t_element *a, t_element *b);
void					swap_params(t_path *this, t_path *that);
int						parent_of(char *a, char *b);
int						is_link(char *path, int modified);
void					print_filename(struct stat sb, char *filename,
						int exception);
void					print_spec_size(dev_t st_dev, long m_maj, long m_min);
void					print_time(time_t mtime);
void					print_size(long size, long max_size);

void					print_group(gid_t grup, int max_group_length);
void					print_owner(uid_t owner, int max_owner_length);
void					print_hardlinks(int n, int maxn);
void					print_rights(struct stat sb, ssize_t xattr);
void					order_params_by_time(t_env *env);
void					order_contents_time(t_env *env);
void					order_all_by_path_time(t_env *env);
void					write_stderror(char *a);
int						empty_path_error(void);
void					append_path_to_end_of_list(t_path **aux, t_path **new,
						t_env **env);
t_path					*new_path(void);
int						add_path(t_env *env, char *path);
int						add_flag(t_env *env, char *flag);
int						valid_flag(char *flag);
void					init_env_and_i(int *i, t_env **env);
int						process_params(int argc, char **argv, t_env *env);
void					init_max(t_dir *dir);
void					append_dir(t_dir **master_dir, char *new_dir);
void					init_spg(t_spg **spg, char *path);
void					handle_nulls(int *len, t_spg *spg, t_dir **dir);
void					process_max_values(char *path, t_dir *dir);
void					print_error(t_dir *dir);
void					init_dir_ep_and_errno(t_dir **dir, t_ep **ep, int *err);
void					process_entry(t_ep **ep, t_dir *this,
						struct dirent *dir);
void					process_file(t_ep *ep, t_dir *this, struct dirent *dir,
						t_dfp *dfp);
void					read_dir(t_dir **current_dir, char *flags);
void					make_sub_paths(t_path *path, char *flags);
void					make_paths(t_env *env);
int						compare_dates(struct tm *d1, struct tm *d2);
void					print_blocks(t_dir *directory);
void					no_such_file_error(char *aux);
void					erase_last_slash(char *aux);
void					remove_first_2(char *aux);
void					print_bad_params(t_env *env);
void					print_file(t_env *env, t_path *params, t_intpair *ip);
void					prepare_dir_print(t_intpair *ip, t_dir *dirs,
						t_path *params, t_env *env);
void					dir_print(t_dir *dirs, t_env *env);
void					print_dir(t_intpair *ip, t_path *params, t_dir **dirs,
						t_env *env);
void					print_all(t_env *env);
void					make_aux(t_dir **aux, t_dir *a);
void					swap_dirs(t_dir *a, t_dir *b);
int						parent_of(char *a, char *b);
int						siblings(char *a, char *b);
void					swap_if_needed(t_dirpair *dp, t_env *env, t_auxpair ap,
						int *swapped);
void					make_auxes(t_auxpair *ap, t_dirpair dp);
void					free_auxes_and_advance(t_auxpair *ap, t_dirpair *dp);
int						init_ss(int *swapped, t_dirpair *dp);
void					order_all_by_path(t_env *env);
void					swap_elems(t_element *a, t_element *b);
int						init_epts2(int *swapped, t_elempair *ep);
int						init_epts1(int *swapped, t_elempair *ep,
						t_dir *subdirs);
int						set_subdirs(t_dir **subdirs, t_path *params);
void					swap_elems_if_needed(t_elempair *ep, t_env *env,
						int *swapped);
void					order_contents(t_env *env);
void					swap_params(t_path *this, t_path *that);
void					init_s_auxes(t_auxpair *ap, t_path *this_next,
						t_lenpair *lp);
void					order_params_classic(t_env *env);
void					init_auxes(t_auxpair *ap, t_lenpair *lp,
						t_path *this_next);
int						init_stuff(int *swapped, t_path **this_next,
						t_path **this);
void					order_params(t_env *env);

#endif
