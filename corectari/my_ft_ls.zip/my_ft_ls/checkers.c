/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checkers.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/28 17:41:35 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/29 11:46:41 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"
#define LSTAT stat

int		is_dir(char *path)
{
	struct stat	*stats;

	stats = (struct stat*)malloc(sizeof(struct stat));
	LSTAT(path, stats);
	if (S_ISDIR(stats->st_mode))
	{
		free(stats);
		return (1);
	}
	free(stats);
	return (0);
}

int		is_file(char *path)
{
	struct stat *stats;

	stats = (struct stat*)malloc(sizeof(struct stat));
	LSTAT(path, stats);
	if (S_ISREG(stats->st_mode))
	{
		free(stats);
		return (1);
	}
	free(stats);
	return (0);
}

int		is_link(char *path, int modified)
{
	struct stat	*stats;
	char		*aux;

	aux = ft_strdup(path);
	if (modified == 1 && aux[ft_strlen(aux) - 1] == '/')
		aux[ft_strlen(aux) - 1] = '\0';
	stats = malloc(sizeof(struct stat));
	lstat(aux, stats);
	if (S_ISLNK(stats->st_mode) == 1)
	{
		free(stats);
		return (1);
	}
	free(stats);
	free(aux);
	return (0);
}
