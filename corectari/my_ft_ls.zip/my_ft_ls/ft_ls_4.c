/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_4.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:56:30 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 09:07:29 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	print_error(t_dir *dir)
{
	char	*name;

	name = ft_strdup(dir->path);
	if (name[ft_strlen(name) - 1] == '/')
		name = ft_strdup(ft_strsub(dir->path,
					(ft_strrchr(dir->path, '/') - dir->path + 1),
					ft_strlen(dir->path)));
	write_stderror("ls: ");
	write_stderror(name);
	write_stderror(": ");
	write_stderror(strerror(dir->error));
	write_stderror("\n");
}

void	init_dir_ep_and_errno(t_dir **dir, t_ep **ep, int *err)
{
	(*dir)->files = (t_element*)malloc(sizeof(t_element));
	(*dir)->error = 0;
	(*dir)->files->path = NULL;
	(*dir)->files->next = NULL;
	*ep = malloc(sizeof(t_ep));
	*err = 0;
}

void	process_entry(t_ep **ep, t_dir *this, struct dirent *dir)
{
	(*ep)->next = (t_element*)malloc(sizeof(t_element));
	(*ep)->next->path = NULL;
	(*ep)->next->next = NULL;
	if ((*ep)->contents->path != NULL)
	{
		(*ep)->next->path = (char*)malloc(sizeof(char) * PATH_SIZE);
		ft_strcpy((*ep)->next->path, this->path);
		if (this->path[ft_strlen(this->path) - 1] != '/')
			ft_strcat((*ep)->next->path, "/");
		ft_strcat((*ep)->next->path, dir->d_name);
		(*ep)->contents->next = (*ep)->next;
		(*ep)->contents = (*ep)->contents->next;
	}
	else
	{
		(*ep)->contents->path = (char*)malloc(sizeof(char) * PATH_SIZE);
		ft_strcpy((*ep)->contents->path, this->path);
		if (this->path[ft_strlen(this->path) - 1] != '/')
			ft_strcat((*ep)->contents->path, "/");
		ft_strcat((*ep)->contents->path, dir->d_name);
	}
}

void	process_file(t_ep *ep, t_dir *this, struct dirent *dir, t_dfp *dfp)
{
	process_entry(&ep, this, dir);
	process_max_values(ep->contents->path, this);
	if (ft_strchr(dfp->flags, 'R') && is_dir(ep->contents->path) == 1 &&
			ft_strcmp(dir->d_name, ".") != 0 &&
			ft_strcmp(dir->d_name, "..") != 0)
		append_dir(dfp->current_dir, ep->contents->path);
}

void	read_dir(t_dir **current_dir, char *flags)
{
	t_dir			*this;
	t_ep			*ep;
	DIR				*directory;
	struct dirent	*dir;
	t_dfp			dfp;

	this = *current_dir;
	init_dir_ep_and_errno(&this, &ep, &errno);
	dfp.current_dir = current_dir;
	dfp.flags = flags;
	ep->contents = this->files;
	directory = opendir(this->path);
	if (directory == NULL && errno != 0)
	{
		this->error = errno;
		return ;
	}
	dir = readdir(directory);
	while (dir)
	{
		if ((dir->d_name[0] == '.' && ft_strchr(flags, 'a')) ||
				dir->d_name[0] != '.')
			process_file(ep, this, dir, &dfp);
		dir = readdir(directory);
	}
}
