/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_10.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:59:38 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 09:13:22 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

int		set_subdirs(t_dir **subdirs, t_path *params)
{
	*subdirs = params->subdirs;
	return (1);
}

void	swap_elems_if_needed(t_elempair *ep, t_env *env, int *swapped)
{
	if ((ft_strcmp(ep->this_next->path, ep->this_next->next->path) < 0 &&
		ft_strchr(env->flags, 'r')) ||
		(ft_strcmp(ep->this_next->path, ep->this_next->next->path) > 0 &&
		!ft_strchr(env->flags, 'r')))
	{
		*swapped = 1;
		swap_elems(ep->this_next, ep->this_next->next);
	}
	ep->this_next = ep->this_next->next;
}

void	order_contents(t_env *env)
{
	t_path		*params;
	t_dir		*subdirs;
	t_elempair	ep;
	int			swapped;

	params = env->params;
	while (params)
	{
		if (is_dir(params->path) && set_subdirs(&subdirs, params))
		{
			while (subdirs && init_epts1(&swapped, &ep, subdirs))
			{
				while (swapped && init_epts2(&swapped, &ep))
					while (ep.this_next && ep.this_next->next)
						swap_elems_if_needed(&ep, env, &swapped);
				subdirs = subdirs->next;
			}
		}
		params = params->next;
	}
}

void	swap_params(t_path *this, t_path *that)
{
	t_path *aux;

	aux = malloc(sizeof(t_path));
	aux->path = this->path;
	aux->subdirs = this->subdirs;
	aux->modified = this->modified;
	this->path = that->path;
	this->subdirs = that->subdirs;
	this->modified = that->modified;
	that->path = aux->path;
	that->subdirs = aux->subdirs;
	that->modified = aux->modified;
	free(aux);
}

void	init_s_auxes(t_auxpair *ap, t_path *this_next, t_lenpair *lp)
{
	ap->aux1 = malloc(sizeof(char) * PATH_SIZE);
	ap->aux2 = malloc(sizeof(char) * PATH_SIZE);
	ap->aux1 = ft_strcpy(ap->aux1, this_next->path);
	ap->aux2 = ft_strcpy(ap->aux2, this_next->next->path);
	lp->len1 = ft_strlen(ap->aux1) - 1;
	lp->len2 = ft_strlen(ap->aux2) - 1;
	if (ap->aux1[lp->len1] == '/')
		ap->aux1[lp->len1] = '\0';
	if (ap->aux2[lp->len2] == '/')
		ap->aux2[lp->len2] = '\0';
}
