/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_opt_l_group_size.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:38:14 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 07:38:50 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	no_group(gid_t group, int max_group_length)
{
	unsigned long i;

	i = 0;
	ft_putstr(ft_itoa((int)group));
	if (max_group_length > 0)
		while (i < max_group_length - ft_strlen(ft_itoa((int)group)))
		{
			write(1, " ", 1);
			i++;
		}
	ft_putstr("  ");
}

void	have_group(struct group *grp, int max_group_length)
{
	unsigned long i;

	i = 0;
	ft_putstr(grp->gr_name);
	if (max_group_length > 0)
		while (i < max_group_length - ft_strlen(grp->gr_name))
		{
			write(1, " ", 1);
			i++;
		}
	ft_putstr("  ");
}

void	print_group(gid_t group, int max_group_length)
{
	struct group	*grp;

	grp = getgrgid(group);
	if (grp == NULL)
		no_group(group, max_group_length);
	else
		have_group(grp, max_group_length);
}

void	print_size(long size, long max_size)
{
	int x;
	int i;

	x = ft_strlen(ft_itoa(size));
	i = 0;
	if (max_size > 0)
		while (i < max_size - x)
		{
			write(1, " ", 1);
			i++;
		}
	ft_putnbr(size);
	write(1, " ", 1);
}

void	print_spec_size(dev_t st_dev, long m_maj, long m_min)
{
	int	i;
	int	my_maj;
	int	my_min;

	my_maj = ft_strlen(ft_itoa(major(st_dev)));
	i = 0;
	if (my_maj > 0)
		while (i < m_maj - my_maj)
		{
			write(1, " ", 1);
			i++;
		}
	ft_putnbr(major(st_dev));
	ft_putstr(", ");
	my_min = ft_strlen(ft_itoa(minor(st_dev)));
	i = 0;
	if (my_min > 0)
		while (i < m_min - my_min)
		{
			write(1, " ", 1);
			i++;
		}
	ft_putnbr(minor(st_dev));
	ft_putchar(' ');
}
