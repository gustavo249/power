/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_opt_t_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:45:40 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 07:46:19 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

int		init_swapped(int *swapped, t_pathpair *tp)
{
	*swapped = 0;
	tp->this_next = tp->this;
	return (1);
}

void	swap_params_if_needed(int *swapped, t_pathpair *tp, t_statpair *sp,
		t_env *env)
{
	if (
(sp->a_stat->st_mtime > sp->b_stat->st_mtime && ft_strchr(env->flags, 'r')) ||
(sp->a_stat->st_mtime < sp->b_stat->st_mtime && !ft_strchr(env->flags, 'r')))
	{
		*swapped = 1;
		swap_params(tp->this_next, tp->this_next->next);
	}
	else if (sp->a_stat->st_mtime == sp->b_stat->st_mtime &&
			((ft_strcmp(tp->this_next->path, tp->this_next->next->path) < 0 &&
			ft_strchr(env->flags, 'r')) ||
			(ft_strcmp(tp->this_next->path, tp->this_next->next->path) > 0 &&
			!ft_strchr(env->flags, 'r'))))
	{
		*swapped = 1;
		swap_params(tp->this_next, tp->this_next->next);
	}
}

void	order_params_by_time(t_env *env)
{
	t_pathpair	tp;
	t_statpair	sp;
	int			swapped;

	swapped = 1;
	tp.this = env->params;
	while (swapped && init_swapped(&swapped, &tp))
		while (tp.this_next && tp.this_next->next)
		{
			sp.a_stat = malloc(sizeof(struct stat));
			sp.b_stat = malloc(sizeof(struct stat));
			lstat(tp.this_next->path, sp.a_stat);
			lstat(tp.this_next->next->path, sp.b_stat);
			if (siblings(tp.this_next->path, tp.this_next->next->path) == 1)
				swap_params_if_needed(&swapped, &tp, &sp, env);
			free(sp.a_stat);
			free(sp.b_stat);
			tp.this_next = tp.this_next->next;
		}
}
