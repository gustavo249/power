/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_opt_l_rights_h_owner.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:37:32 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 07:37:49 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	print_hardlinks(int n, int maxn)
{
	int x;
	int i;
	int	maxlen;

	maxlen = ft_strlen(ft_itoa(maxn));
	x = ft_strlen(ft_itoa(n));
	i = 0;
	while (i < maxlen - x)
	{
		write(1, " ", 1);
		i++;
	}
	ft_putnbr(n);
	ft_putchar(' ');
}

void	no_owner(uid_t owner, int max_owner_length)
{
	unsigned long i;

	i = 0;
	ft_putstr(ft_itoa((int)owner));
	if (max_owner_length > 0)
		while (i < max_owner_length - ft_strlen(ft_itoa((int)owner)))
		{
			write(1, " ", 1);
			i++;
		}
	ft_putchar(' ');
	ft_putchar(' ');
}

void	have_owner(struct passwd *pwd, int max_owner_length)
{
	unsigned long i;

	i = 0;
	ft_putstr(pwd->pw_name);
	if (max_owner_length > 0)
		while (i < max_owner_length - ft_strlen(pwd->pw_name))
		{
			write(1, " ", 1);
			i++;
		}
	ft_putchar(' ');
	ft_putchar(' ');
}

void	print_owner(uid_t owner, int max_owner_length)
{
	struct passwd *pwd;

	pwd = getpwuid(owner);
	if (pwd == NULL)
		no_owner(owner, max_owner_length);
	else
		have_owner(pwd, max_owner_length);
}
