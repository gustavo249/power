/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:55:27 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 09:04:46 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

int		add_path(t_env *env, char *path)
{
	t_path	*aux;
	t_path	*new;

	new = new_path();
	if (ft_strcmp(path, "") == 0)
		return (empty_path_error());
	if (ft_strchr(path, '/') == NULL && is_dir(path) == 0)
	{
		new->modified = 1;
		ft_strcpy(new->path, "./");
	}
	ft_strcat(new->path, path);
	if (new->path[ft_strlen(new->path) - 1] != '/' && is_dir(path) == 1)
	{
		new->modified = 1;
		ft_strcat(new->path, "/");
	}
	if (env->params == NULL)
		env->params = new;
	else
		append_path_to_end_of_list(&aux, &new, &env);
	return (1);
}

int		add_flag(t_env *env, char *flag)
{
	int i;

	i = 1;
	while (flag[i] != '\0')
	{
		if (ft_strchr("1artlR", *(flag + i)) == NULL)
		{
			write_stderror("/bin/ls: illegal option -- ");
			write(2, flag + i, 1);
			write_stderror("\nusage: ls [-ABCFGHLOPRSTUWabcdefghiklmnopqrstu");
			write_stderror("wx1] [file ...]\n");
			return (-1);
		}
		i++;
	}
	env->flags = ft_strcat(env->flags, flag + 1);
	return (1);
}

int		valid_flag(char *flag)
{
	int i;

	i = 1;
	if (flag[1] == '~')
		return (1);
	if (flag[0] != '-')
		return (0);
	while (flag[i] == '-')
		i++;
	if (ft_isalnum(flag[i]) == 0)
		return (0);
	return (1);
}

void	init_env_and_i(int *i, t_env **env)
{
	*i = 1;
	(*env)->flags = (char*)malloc(sizeof(char) * PATH_SIZE);
	(*env)->params = NULL;
}

int		process_params(int argc, char **argv, t_env *env)
{
	int i;

	init_env_and_i(&i, &env);
	if (i < argc && ft_strcmp(argv[i], "--") != 0)
	{
		while (i < argc && argv[i][0] == '-' && valid_flag(argv[i]) == 1)
		{
			if (add_flag(env, argv[i]) == -1)
				return (-1);
			i++;
		}
		if (i < argc && valid_flag(argv[i]) == 0 &&
				ft_strcmp(argv[i], "--") == 0)
			i++;
	}
	else
		i++;
	if (i >= argc)
		add_path(env, "./");
	i--;
	while (++i && i < argc)
		if (add_path(env, argv[i]) == -1)
			return (-1);
	return (1);
}
