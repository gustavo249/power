/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_opt_l_rights.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:36:15 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 07:36:55 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	type(struct stat sb)
{
	if (S_ISREG(sb.st_mode) == 1)
		ft_putchar('-');
	if (S_ISDIR(sb.st_mode) == 1)
		ft_putchar('d');
	if (S_ISCHR(sb.st_mode) == 1)
		ft_putchar('c');
	if (S_ISBLK(sb.st_mode) == 1)
		ft_putchar('b');
	if (S_ISFIFO(sb.st_mode) == 1)
		ft_putchar('f');
	if (S_ISLNK(sb.st_mode) == 1)
		ft_putchar('l');
	if (S_ISSOCK(sb.st_mode) == 1)
		ft_putchar('s');
}

void	first_part(struct stat sb)
{
	if (sb.st_mode & S_IRUSR)
		ft_putchar('r');
	else
		ft_putchar('-');
	if (sb.st_mode & S_IWUSR)
		ft_putchar('w');
	else
		ft_putchar('-');
	if (sb.st_mode & S_ISUID && (S_IEXEC & sb.st_mode))
		ft_putchar('s');
	else if (sb.st_mode & S_ISUID)
		ft_putchar('S');
	else if (sb.st_mode & S_IXUSR)
		ft_putchar('x');
	else
		ft_putchar('-');
}

void	second_part(struct stat sb)
{
	if (sb.st_mode & S_IRGRP)
		ft_putchar('r');
	else
		ft_putchar('-');
	if (sb.st_mode & S_IWGRP)
		ft_putchar('w');
	else
		ft_putchar('-');
	if (sb.st_mode & S_ISGID && (sb.st_mode & S_IREAD))
		ft_putchar('s');
	else if (sb.st_mode & S_ISGID)
		ft_putchar('S');
	else if (sb.st_mode & S_IXGRP)
		ft_putchar('x');
	else
		ft_putchar('-');
}

void	third_part(struct stat sb)
{
	if (sb.st_mode & S_IROTH)
		ft_putchar('r');
	else
		ft_putchar('-');
	if (sb.st_mode & S_IWOTH)
		ft_putchar('w');
	else
		ft_putchar('-');
	if (sb.st_mode & S_ISVTX && (sb.st_mode & S_IEXEC))
		ft_putchar('t');
	else if (sb.st_mode & S_ISVTX)
		ft_putchar('T');
	else if (sb.st_mode & S_IXOTH)
		ft_putchar('x');
	else
		ft_putchar('-');
}

void	print_rights(struct stat sb, ssize_t xattr)
{
	type(sb);
	first_part(sb);
	second_part(sb);
	third_part(sb);
	if (xattr > 0)
		ft_putchar('@');
	else
		ft_putchar(' ');
	ft_putchar(' ');
}
