/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_3.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:56:04 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 07:56:17 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	init_max(t_dir *dir)
{
	dir->max_user_len = 0;
	dir->max_group_len = 0;
	dir->max_hardlinks = 0;
	dir->max_size = 0;
	dir->m_maj = 0;
	dir->m_min = 0;
}

void	append_dir(t_dir **master_dir, char *new_dir)
{
	t_dir *this;
	t_dir *new;

	this = *master_dir;
	while (this->next)
		this = this->next;
	new = (t_dir*)malloc(sizeof(t_dir));
	new->path = (char*)malloc(sizeof(char) * PATH_SIZE);
	new->files = NULL;
	new->next = NULL;
	init_max(new);
	ft_strcpy(new->path, new_dir);
	ft_strcat(new->path, "/");
	this->next = new;
}

void	init_spg(t_spg **spg, char *path)
{
	*spg = malloc(sizeof(t_spg));
	(*spg)->stats = malloc(sizeof(struct stat));
	lstat(path, (*spg)->stats);
	(*spg)->pwd = getpwuid((*spg)->stats->st_uid);
	(*spg)->grp = getgrgid((*spg)->stats->st_gid);
}

void	handle_nulls(int *len, t_spg *spg, t_dir **dir)
{
	if (spg->pwd == NULL)
		*len = ft_strlen(ft_itoa(spg->stats->st_uid));
	else
		*len = ft_strlen(spg->pwd->pw_name);
	if (*len > (*dir)->max_user_len)
		(*dir)->max_user_len = *len;
	if (spg->pwd == NULL)
		*len = ft_strlen(ft_itoa(spg->stats->st_gid));
	else
		*len = ft_strlen(spg->grp->gr_name);
	if (*len > (*dir)->max_group_len)
		(*dir)->max_group_len = *len;
	if (spg->stats->st_nlink > (*dir)->max_hardlinks)
		(*dir)->max_hardlinks = spg->stats->st_nlink;
}

void	process_max_values(char *path, t_dir *dir)
{
	t_spg	*spg;
	int		len;

	init_spg(&spg, path);
	handle_nulls(&len, spg, &dir);
	if (S_ISBLK(spg->stats->st_mode) || S_ISCHR(spg->stats->st_mode))
	{
		len = ft_strlen(ft_itoa(major(spg->stats->st_rdev)));
		if (len > dir->m_maj)
			dir->m_maj = len;
		len = ft_strlen(ft_itoa(minor(spg->stats->st_rdev)));
		if (len > dir->m_min)
			dir->m_min = len;
	}
	else if ((int)ft_strlen(ft_itoa(spg->stats->st_size)) >
			dir->max_size)
		dir->max_size = ft_strlen(ft_itoa(spg->stats->st_size));
	if (spg)
		free(spg);
}
