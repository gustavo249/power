/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_7.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:57:46 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 09:09:14 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	dir_print(t_dir *dirs, t_env *env)
{
	t_element *files;

	files = dirs->files;
	if (files->path && ft_strchr(env->flags, 'l'))
		print_blocks(dirs);
	while (files)
	{
		if (files->path != NULL)
		{
			if (!ft_strchr(env->flags, 'l'))
			{
				ft_putendl(ft_strsub(files->path, ft_strrchr(files->path, '/') -
							files->path + 1, ft_strlen(files->path) -
							(ft_strrchr(files->path, '/') - files->path)));
			}
			else
				display_contents(files->path, dirs, 0);
		}
		files = files->next;
	}
}

void	print_dir(t_intpair *ip, t_path *params, t_dir **dirs, t_env *env)
{
	prepare_dir_print(ip, *dirs, params, env);
	if ((*dirs)->error != 0)
		print_error((*dirs));
	else
		dir_print((*dirs), env);
	(*dirs) = (*dirs)->next;
}

void	print_all(t_env *env)
{
	t_path		*params;
	t_dir		*dirs;
	t_intpair	ip;

	params = env->params;
	ip.first = 1;
	while (params)
	{
		ip.first_for_param = 1;
		dirs = params->subdirs;
		if (params->path == NULL || ft_strcmp(params->path, "") == 0)
			;
		else if (!dirs && (is_link(params->path, params->modified) == 0 ||
					is_dir(params->path) == 0))
			print_file(env, params, &ip);
		else if (is_link(params->path, params->modified) == 1 &&
				ft_strchr(env->flags, 'l'))
			display_contents(params->path, NULL, 1);
		else
			while (dirs)
				print_dir(&ip, params, &dirs, env);
		params = params->next;
	}
}

void	make_aux(t_dir **aux, t_dir *a)
{
	*aux = malloc(sizeof(t_dir));
	(*aux)->max_user_len = a->max_user_len;
	(*aux)->max_group_len = a->max_group_len;
	(*aux)->max_hardlinks = a->max_hardlinks;
	(*aux)->max_size = a->max_size;
	(*aux)->m_maj = a->m_maj;
	(*aux)->m_min = a->m_min;
	(*aux)->error = a->error;
	(*aux)->path = a->path;
	(*aux)->files = a->files;
}

void	swap_dirs(t_dir *a, t_dir *b)
{
	t_dir *aux;

	make_aux(&aux, a);
	a->max_user_len = b->max_user_len;
	a->max_group_len = b->max_group_len;
	a->max_hardlinks = b->max_hardlinks;
	a->max_size = b->max_size;
	a->m_maj = b->m_maj;
	a->m_min = b->m_min;
	a->error = b->error;
	a->path = b->path;
	a->files = b->files;
	b->max_user_len = aux->max_user_len;
	b->max_group_len = aux->max_group_len;
	b->max_hardlinks = aux->max_hardlinks;
	b->max_size = aux->max_size;
	b->m_maj = aux->m_maj;
	b->m_min = aux->m_min;
	b->error = aux->error;
	b->path = aux->path;
	b->files = aux->files;
	free(aux);
}
