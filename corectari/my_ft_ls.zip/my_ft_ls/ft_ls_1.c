/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_1.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 07:55:02 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 09:03:24 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	write_stderror(char *a)
{
	int i;
	int len;

	len = ft_strlen(a);
	i = 0;
	while (i < len)
	{
		write(2, a + i, 1);
		i++;
	}
}

int		empty_path_error(void)
{
	write_stderror("ls: fts_open: No such file or directory\n");
	return (-1);
}

void	append_path_to_end_of_list(t_path **aux, t_path **new, t_env **env)
{
	*aux = (*env)->params;
	while ((*aux)->next)
		*aux = (*aux)->next;
	(*aux)->next = *new;
}

t_path	*new_path(void)
{
	t_path	*newp;

	newp = (t_path*)malloc(sizeof(t_path));
	newp->path = (char*)malloc(sizeof(char) * PATH_SIZE);
	newp->subdirs = NULL;
	newp->next = NULL;
	newp->modified = 0;
	return (newp);
}
