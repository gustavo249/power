/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/11/24 15:40:29 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 08:01:28 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

int		main(int argc, char **argv)
{
	t_env	*env;

	env = (t_env*)malloc(sizeof(t_env));
	if (process_params(argc, argv, env) == -1)
		return (0);
	make_paths(env);
	order_params_classic(env);
	print_bad_params(env);
	if (ft_strchr(env->flags, 't'))
	{
		order_params_by_time(env);
		order_all_by_path(env);
		order_contents_time(env);
	}
	else
	{
		order_params(env);
		order_all_by_path(env);
		order_contents(env);
	}
	print_all(env);
	return (0);
}
