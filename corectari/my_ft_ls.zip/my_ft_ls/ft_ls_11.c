/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls_11.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alstanci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/30 08:00:03 by alstanci          #+#    #+#             */
/*   Updated: 2015/12/30 08:00:36 by alstanci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	order_params_classic(t_env *env)
{
	t_path		*this;
	t_path		*this_next;
	int			swapped;
	t_auxpair	ap;
	t_lenpair	lp;

	this = env->params;
	swapped = 1;
	while (swapped)
	{
		swapped = 0;
		this_next = this;
		while (this_next && this_next->next)
		{
			init_s_auxes(&ap, this_next, &lp);
			if (ft_strcmp(ap.aux1, ap.aux2) > 0)
			{
				swapped = 1;
				swap_params(this_next, this_next->next);
			}
			free(ap.aux1);
			free(ap.aux2);
			this_next = this_next->next;
		}
	}
}

void	init_auxes(t_auxpair *ap, t_lenpair *lp, t_path *this_next)
{
	ap->aux1 = malloc(sizeof(char) * PATH_SIZE);
	ap->aux2 = malloc(sizeof(char) * PATH_SIZE);
	ap->aux1 = ft_strcpy(ap->aux1, this_next->path);
	ap->aux2 = ft_strcpy(ap->aux2, this_next->next->path);
	lp->len1 = ft_strlen(ap->aux1) - 1;
	lp->len2 = ft_strlen(ap->aux2) - 1;
	if (this_next->modified == 1 && ap->aux1[lp->len1] == '/')
		ap->aux1[lp->len1] = '\0';
	if (this_next->next->modified == 1 && ap->aux2[lp->len2] == '/')
		ap->aux2[lp->len2] = '\0';
}

int		init_stuff(int *swapped, t_path **this_next, t_path **this)
{
	*swapped = 0;
	*this_next = *this;
	return (1);
}

void	order_params(t_env *env)
{
	t_path		*this;
	t_path		*this_next;
	int			swapped;
	t_auxpair	ap;
	t_lenpair	lp;

	this = env->params;
	swapped = 1;
	while (swapped && init_stuff(&swapped, &this_next, &this))
		while (this_next && this_next->next)
		{
			init_auxes(&ap, &lp, this_next);
			if (
		(ft_strcmp(ap.aux1, ap.aux2) < 0 && ft_strchr(env->flags, 'r')) ||
		(ft_strcmp(ap.aux1, ap.aux2) > 0 && !ft_strchr(env->flags, 'r')))
			{
				swapped = 1;
				swap_params(this_next, this_next->next);
			}
			free(ap.aux1);
			free(ap.aux2);
			this_next = this_next->next;
		}
}
