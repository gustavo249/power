//
//  FirstViewController.swift
//  Map
//
//  Created by Radudj on 13/02/16.
//  Copyright © 2016 Radudj. All rights reserved.
//

import UIKit
import MapKit

class FirstViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    let ecole42Location = CLLocationCoordinate2DMake(48.849441, 2.346147)
    let regionRadius: CLLocationDistance = 1000
    let startLocation = CLLocation(latitude: 48.849441, longitude: 2.346147)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.mapView.delegate = self
        
        // Drop a pin
        centerMapOnLocation(startLocation)
        let dropPin = MKPointAnnotation()
        dropPin.coordinate = ecole42Location
        dropPin.title = "Ecole 42"
        mapView.addAnnotation(dropPin)

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius / 2, regionRadius / 2)
        mapView.setRegion(coordinateRegion, animated: true)
    }
}

