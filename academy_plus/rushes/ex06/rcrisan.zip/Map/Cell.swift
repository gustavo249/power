//
//  Cell.swift
//  Map
//
//  Created by Radudj on 13/02/16.
//  Copyright © 2016 Radudj. All rights reserved.
//

import Foundation
import UIKit

class Cell: UITableViewCell {
    
    @IBOutlet weak var name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}