//
//  SecondViewController.swift
//  Map
//
//  Created by Radudj on 13/02/16.
//  Copyright © 2016 Radudj. All rights reserved.
//

import UIKit

struct TableViewControllerConstants {
    static let cellIdentifier = "Identifier"
}

class SecondViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    var bars: [String]? = ["Bar 1", "Bar 2", "Bar 3"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        
        
        let cell = UINib(nibName: "Cell", bundle: NSBundle.mainBundle())
        tableView.registerNib(cell, forCellReuseIdentifier: TableViewControllerConstants.cellIdentifier)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let returnCell = tableView.dequeueReusableCellWithIdentifier(TableViewControllerConstants.cellIdentifier, forIndexPath: indexPath) as UITableViewCell
        
        returnCell.textLabel?.text = bars![indexPath.row]
        
        return returnCell
    }
    
    public func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    
    
}

