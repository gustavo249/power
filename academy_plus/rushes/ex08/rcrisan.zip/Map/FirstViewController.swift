//
//  FirstViewController.swift
//  Map
//
//  Created by Radudj on 13/02/16.
//  Copyright © 2016 Radudj. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class FirstViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    @IBAction func segmented(sender: AnyObject) {
        switch sender.selectedSegmentIndex {
            case 1: mapView.mapType = MKMapType.Satellite
            case 2: mapView.mapType = MKMapType.Hybrid
            default: mapView.mapType = MKMapType.Standard
        }
    }
    let ecole42Location = CLLocationCoordinate2DMake(48.849441, 2.346147)
    let regionRadius: CLLocationDistance = 1000
    let startLocation = CLLocation(latitude: 48.849441, longitude: 2.346147)
    var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.mapView.delegate = self
        
        // Drop a pin
        centerMapOnLocation(startLocation)
        let dropPin = MKPointAnnotation()
        dropPin.coordinate = ecole42Location
        dropPin.title = "Ecole 42"
        mapView.addAnnotation(dropPin)

        // Do any additional setup after loading the view, typically from a nib.
//        self.locationManager.delegate = self
        self.locationManager.distanceFilter = kCLDistanceFilterNone
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.pausesLocationUpdatesAutomatically = false
        self.locationManager.startUpdatingLocation()
        self.locationManager.delegate = self
        //merge pana aici
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius / 2, regionRadius / 2)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    func locationManager(manager: CLLocationManager, didUpdateToLocation newLocation: CLLocation, fromLocation oldLocation: CLLocation) {
        NSLog("OldLocation %f %f", oldLocation.coordinate.latitude, oldLocation.coordinate.longitude)
        NSLog("NewLocation %f %f", newLocation.coordinate.latitude, newLocation.coordinate.longitude)
        let currentAnnot = MKPointAnnotation()
        let myPos = CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude)
        let getLat = newLocation.coordinate.latitude
        let getLog = newLocation.coordinate.longitude
        let center = CLLocation(latitude: getLat, longitude: getLog)
        currentAnnot.coordinate = myPos
        self.mapView.addAnnotation(currentAnnot)
        self.mapView.showsUserLocation = true
        centerMapOnLocation(center as CLLocation)
    }
}

